@echo off
setlocal
cd /d "%~dp0"

echo.
echo ==========================================================
echo    PCL Download Fix - restoring original
echo ==========================================================
echo.

if not exist "%~dp0Patch-PCL.ps1" (
    echo   [X] Patch-PCL.ps1 not found in this folder.
    echo.
    pause
    exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Patch-PCL.ps1" -Restore %*
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" (
    echo   Restored to original.
) else (
    echo   Restore failed, exit code %RC%
)

echo.
echo   Press any key to close...
pause >nul
exit /b %RC%

@echo off
setlocal
cd /d "%~dp0"

echo.
echo ==========================================================
echo    PCL Download Fix - applying patch
echo ==========================================================
echo.

if not exist "%~dp0Patch-PCL.ps1" (
    echo   [X] Patch-PCL.ps1 not found in this folder.
    echo.
    pause
    exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Patch-PCL.ps1" %*
set "RC=%ERRORLEVEL%"

echo.
if "%RC%"=="0" (
    echo   Finished successfully.
) else (
    echo   Finished with exit code %RC% - see messages above.
)

echo.
echo   Press any key to close...
pause >nul
exit /b %RC%

﻿#Requires -Version 5.1
<#
.SYNOPSIS
    为 PCL 2 恢复「下载」页与「整合包安装」功能（仅供自用，请勿传播）。

.DESCRIPTION
    PCL 2.99.0.0 起，作者把下载页的加载器替换为直接抛异常的占位实现，
    并在整合包安装入口前加了「提示 + 立即返回」的硬拦截。

    本脚本不重新编译，而是直接改写 exe 内这两处方法的 IL 字节：
      1) PageDownloadInstall.LoaderInit : 抛异常的 LoaderTask -> 真实的 DlClientListLoader
      2) ModModpack.ModpackInstall      : 去掉方法开头的拦截闸门

    所有位置（RVA、token、区间）均在运行时从当前 exe 动态推算，
    因此 PCL 升级后重新运行一次即可，无需修改脚本。

.PARAMETER PclPath
    PCL 主程序路径。省略时自动查找。

.PARAMETER Restore
    从 .bak-original 备份还原，撤销补丁。

.EXAMPLE
    .\Patch-PCL.ps1

.EXAMPLE
    .\Patch-PCL.ps1 -Restore
#>
[CmdletBinding()]
param(
    [string]$PclPath,
    [switch]$Restore
)

$ErrorActionPreference = 'Stop'
$root      = Split-Path -Parent $MyInvocation.MyCommand.Path
$cecil     = Join-Path $root 'tools\Mono.Cecil.dll'
$codeFile  = Join-Path $root 'tools\patchcode.b64'

function Say  ($m) { Write-Host "  $m" }
function Good ($m) { Write-Host "  [OK] $m" -ForegroundColor Green }
function Warn ($m) { Write-Host "  [!]  $m" -ForegroundColor Yellow }
function Bad  ($m) { Write-Host "  [X]  $m" -ForegroundColor Red }

Write-Host ''
Write-Host '  PCL 下载功能修复工具' -ForegroundColor Cyan
Write-Host ('  ' + ('-' * 50)) -ForegroundColor DarkGray

# ---------- 前置检查 ----------
if (-not (Test-Path $cecil))    { Bad "缺少 $cecil";    exit 1 }
if (-not (Test-Path $codeFile)) { Bad "缺少 $codeFile"; exit 1 }

# ---------- 查找 exe ----------
if (-not $PclPath) {
    $guess = @('E:\Plain Craft Launcher 2.exe', (Join-Path $root 'Plain Craft Launcher 2.exe'))
    $PclPath = $guess | Where-Object { Test-Path $_ } | Select-Object -First 1

    if (-not $PclPath) {
        foreach ($drv in 'C:\','D:\','E:\','F:\') {
            if (-not (Test-Path $drv)) { continue }
            $hit = Get-ChildItem -Path $drv -Filter 'Plain Craft Launcher 2.exe' -File `
                       -Recurse -Depth 3 -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($hit) { $PclPath = $hit.FullName; break }
        }
    }
}

if (-not $PclPath -or -not (Test-Path $PclPath)) {
    Bad '未找到 PCL 主程序，请指定路径：'
    Write-Host '      .\Patch-PCL.ps1 -PclPath "E:\Plain Craft Launcher 2.exe"'
    exit 1
}
$PclPath    = (Resolve-Path $PclPath).Path
$backupPath = "$PclPath.bak-original"

Say "目标文件 : $PclPath"
Say "文件大小 : $((Get-Item $PclPath).Length) 字节"

# ---------- 还原 ----------
if ($Restore) {
    if (-not (Test-Path $backupPath)) { Bad "找不到备份：$backupPath"; exit 1 }
    if (Get-Process -Name 'Plain Craft Launcher 2' -ErrorAction SilentlyContinue) {
        Bad '请先完全退出 PCL 再还原。'; exit 1
    }
    Copy-Item $backupPath $PclPath -Force
    Good "已还原为原版：$backupPath"
    exit 0
}

# ---------- 占用检查 ----------
$proc = Get-Process -Name 'Plain Craft Launcher 2' -ErrorAction SilentlyContinue
if ($proc) {
    Bad "PCL 正在运行（PID $($proc.Id -join ',')），请先完全退出。"
    exit 1
}

# ---------- 加载补丁逻辑 ----------
try {
    Add-Type -Path $cecil
    if (-not ('PclDownloadFixer' -as [type])) {
        $src = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String((Get-Content $codeFile -Raw)))
        Add-Type -TypeDefinition $src -ReferencedAssemblies $cecil
    }
    Say '补丁引擎已就绪'
} catch {
    Bad "初始化失败：$($_.Exception.Message)"
    exit 1
}

# ---------- 执行 ----------
try {
    $r = [PclDownloadFixer]::Run($PclPath, $true)
} catch {
    $m = $_.Exception.Message
    if ($_.Exception.InnerException) { $m = $_.Exception.InnerException.Message }
    Bad "打补丁失败：$m"
    Write-Host ''
    Write-Host '     原文件未被修改，可放心重试。' -ForegroundColor DarkGray
    exit 1
}

Write-Host ''
foreach ($line in $r.Log) { Say $line }
Write-Host ''

if ($r.AlreadyPatched) {
    Good '当前文件无需修改（已是可下载状态）。'
    Write-Host '       可能原因：已打过补丁，或该版本本身就没有此限制。' -ForegroundColor DarkGray
    exit 0
}

# ---------- 复核 ----------
try {
    $asm = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($PclPath)
    $m1 = $asm.MainModule.GetTypes() | Where-Object { $_.FullName -eq 'PCL.PageDownloadInstall' } |
          ForEach-Object { $_.Methods } | Where-Object { $_.Name -eq 'LoaderInit' }
    $m2 = $asm.MainModule.GetTypes() | Where-Object { $_.FullName -eq 'PCL.ModModpack' } |
          ForEach-Object { $_.Methods } | Where-Object { $_.Name -eq 'ModpackInstall' }

    $okLoader = [bool]($m1.Body.Instructions | Where-Object {
        $_.Operand -and $_.Operand.ToString() -match 'DlClientListLoader' })
    $okGate = -not [bool]($m2.Body.Instructions | Select-Object -First 12 |
        Where-Object { $_.OpCode.Name -eq 'ret' })
    $asm.Dispose()

    if ($okLoader) { Good '复核：下载页已接回真实加载器' } else { Warn '复核：LoaderInit 似未生效' }
    if ($okGate)   { Good '复核：整合包安装已解锁' }     else { Warn '复核：ModpackInstall 仍有闸门' }
} catch {
    Warn "复核跳过：$($_.Exception.Message)"
}

Write-Host ''
Write-Host ('  ' + ('-' * 50)) -ForegroundColor DarkGray
Write-Host '  完成，启动 PCL 即可看到下载页恢复。' -ForegroundColor Green
Write-Host ''
Write-Host '  提醒：' -ForegroundColor Yellow
Write-Host '   - PCL 自动更新会覆盖补丁，更新后重跑本脚本即可'
Write-Host '   - 还原：.\Patch-PCL.ps1 -Restore'
Write-Host '   - 本补丁仅供自用，请勿传播' -ForegroundColor Yellow
Write-Host ''

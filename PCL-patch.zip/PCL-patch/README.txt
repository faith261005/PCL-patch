﻿PCL 下载功能修复工具
====================

【新手请看】使用说明.txt  —— 包含完整的操作步骤、故障排除、
                              跨电脑使用说明和常见问题解答。

本文档是技术背景说明（进阶阅读），供想了解原理时查阅。

用途
----
恢复 PCL 2（2.99.0.0 起）被移除的「下载」页与「整合包安装」功能。

背景
----
PCL 2.99.0.0 的官方更新说明写着：

    为遵守相关法律法规，PCL 不再提供 MC 下载功能，非常抱歉 qwq……

对应到源码是两处：

    ' Modules/ModSecret.vb
    Public Const RestrictMcDownload As Boolean = True

    ' Pages/PageDownload/PageDownloadInstall.xaml.vb
    If RestrictMcDownload Then
        PageLoaderInit(..., New LoaderTask("关闭下载",
            Sub() Throw New Exception("为遵守相关法律法规，PCL 暂时不再提供 MC 下载功能…")), ...)
    Else
        PageLoaderInit(..., DlClientListLoader, ...)   ' 真正的下载器
    End If

因为 RestrictMcDownload 是 Const，编译器把它内联后直接删掉了 Else 分支，
所以换下载源、改镜像、清缓存都无法恢复——必须在 IL 层面改。

本工具做的事
------------
不重新编译（官方开源版是删减版，缺更新/赞助功能，且没有微软登录 ClientId），
而是直接改写 exe 里两处方法的 IL 字节：

  1) PCL.PageDownloadInstall::LoaderInit
     把「抛异常的 LoaderTask」替换为真实的 PCL.ModDownload.DlClientListLoader

  2) PCL.ModModpack::ModpackInstall
     把方法开头的「Hint(...) + Return」拦截闸门全部 nop 掉

所有位置（RVA、元数据 token、替换区间）都是运行时从当前 exe 动态推算的，
不写死任何地址，所以 PCL 升级后重跑一次即可。

用法
----
【方式一：双击运行（最简单，推荐普通用户）】

     apply-patch.bat        打补丁
     restore-original.bat   撤销补丁

   双击即可，会自动完成全部检查并在结束时停住窗口，方便看结果。

     注意：本机 PowerShell 执行策略是 Restricted，
     直接双击 .ps1 会被静默拦截（没有任何提示，退出码 1），
     所以请用上面的 bat，或按方式二手动运行。

【方式二：命令行运行】

1. 完全退出 PCL（托盘图标也要退）

2. 打开 PowerShell（Win+X 选「终端」或「Windows PowerShell」），执行：

       cd E:\PCL-patch
       powershell -NoProfile -ExecutionPolicy Bypass -File .\Patch-PCL.ps1

   若 PCL 不在默认位置：

       powershell -NoProfile -ExecutionPolicy Bypass -File .\Patch-PCL.ps1 -PclPath "D:\Games\Plain Craft Launcher 2.exe"

3. 撤销补丁：

       powershell -NoProfile -ExecutionPolicy Bypass -File .\Patch-PCL.ps1 -Restore

   -ExecutionPolicy Bypass 只对这一次运行生效，不会改动系统设置。

首次运行会生成备份 `Plain Craft Launcher 2.exe.bak-original`，
原版 sha256 = 6B6E1260CB5A1D6A303855F1C60CAB3D0BC1AEBBA7E40A964180188B271E7386

如果提示「无法访问文件」
------------------------
说明 PCL 还在运行。任务管理器里结束所有 "Plain Craft Launcher 2" 进程后重试。
脚本对这种情况有保护：失败时不会写坏原文件。

脚本特性
--------
· 幂等：已打过补丁会自动识别，不会重复修改
· 安全：所有结构校验不通过就中止，绝不半途写入
· 自校验：打完会重新读取 exe 复核两处补丁是否生效
· 失败重试：写回遇到文件占用会自动等待重试

已验证结果
----------
PCL 2.99.0.0 实测：
· 脚本输出与手工补丁结果逐字节一致（sha256 = 5992425A…5F63）
· 启动无异常，日志无 InvalidProgramException
· 下载页正常显示「原版游戏 / 26.3 / 26.4-snapshot-5 / 正式版 / 预览版 / 远古版」
· 进入版本安装页正常显示 Forge / NeoForge / Fabric「可以添加」

关于下载源（重要）
------------------
实测 BMCLAPI 镜像在国内**并不稳定**：

    plain         : http=200  time=4.16s
    attempt 1~2   : http=200  time≈3.7s
    attempt 3     : http=200  time=10.28s
    with PCL hdrs : http=302  time=22.5s  (超时)
    curl: (28) Failed to connect to 19.749333.xyz:443

而 Mojang 官方源在本机稳定 0.9~2.8s。

因此推荐设置（本项目已配置）：
    HKCU\Software\PCL
        ToolDownloadSource  = 2   (官方源优先，失败自动回落镜像)
        ToolDownloadVersion = 2

取值含义（从 get_DlSourcePreferMojang 的 IL 还原）：
    2 -> PreferMojang = true   官方源优先
    1 -> 由 DlPreferMojang 自动判断
    0 -> PreferMojang = false  镜像优先

注意事项
--------
1. PCL 自动更新会覆盖本补丁。更新后重跑 Patch-PCL.ps1 即可。
   建议在 PCL 设置里关闭自动更新，避免被静默覆盖。

2. 本补丁是绕过作者基于合规考量主动加入的限制。
   请仅限自用，不要分发、不要上传网盘或论坛。

文件清单
--------
    apply-patch.bat          双击打补丁（推荐）
    restore-original.bat     双击撤销补丁
    Patch-PCL.ps1            主脚本（实际逻辑）
    tools\Mono.Cecil.dll     解析/分析 .NET 元数据（只在读时使用）
    tools\patchcode.b64      补丁逻辑（C#，Base64 存放，避免中文编码问题）
    README.txt               本文件
